## ---- eval=FALSE---------------------------------------------------------
#  install.packages("bcops", repos = "https://cran.us.r-project.org")

